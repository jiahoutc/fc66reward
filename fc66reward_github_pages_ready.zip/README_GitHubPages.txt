
# FC66 Reward — GitHub Pages 静态版（方案B）

这是适合放在 GitHub Pages 的版本（**无后台 / 无 PHP**）。
你可以通过 **直接编辑 `config.json`** 来控制：背景、音乐、奖励、按钮链接与玩法。

## 部署步骤（GitHub Pages）
1) 在 GitHub 创建一个新仓库（例如 `fc66reward`），保持 **Public**。
2) 把本包所有文件上传到仓库根目录（包括 `index.html`、`config.json`、`uploads/`）。
3) 进入仓库：Settings → Pages → "Build and deployment"
   - Source 选：**Deploy from a branch**
   - Branch 选：**main / root**（或默认分支）
4) 保存后等几分钟，会生成一个地址：`https://你的用户名.github.io/仓库名/`
   - 打开：`https://你的用户名.github.io/仓库名/` 即可访问。

## 绑定自定义域名（fc66reward.com）
1) 在 Settings → Pages → "Custom domain" 里输入你的域名（建议 `www.fc66reward.com`），保存。
2) 按 GitHub 提示，到你的域名服务商（Namecheap）里：
   - 为 `www` 添加 **CNAME** 记录，值填 `你的用户名.github.io`。
   - （可选）把顶级域 `fc66reward.com` **URL 转发**到 `https://www.fc66reward.com`。
3) 生效后，访问 `https://www.fc66reward.com` 即可打开。

## 如何修改外观与内容
- 背景图：把图片上传到 `uploads/` 文件夹，然后在 `config.json` 把 `background.image_url` 改成对应路径。
- 纯色背景：把 `background.type` 改成 `"color"`，并设置 `background.color`。
- 音乐：把 MP3 上传到 `uploads/`，然后在 `config.json` 的 `music.url` 写入路径，并将 `music.enabled` 改成 `true`（如需自动播放，把 `autoplay` 设为 `true`）。
- 奖励：编辑 `rewards` 列表（数组），前台会随机展示其中一条作为中奖提示。
- 按钮：改 `claim.button_text` 与 `claim.link`。

提示：GitHub Pages 会缓存静态资源，首次更新后等待数分钟即可刷新。
